package com.example.shualeduricda5.Leave

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.shualeduricda5.R
import com.example.shualeduricda5.SubmitLeaveFragment
import com.example.shualeduricda5.adapters.ViewpagerAdapter
import com.example.shualeduricda5.databinding.FragmentLeaveBinding
import com.example.shualeduricda5.Leave.fragments.ApprovedFragment
import com.example.shualeduricda5.Leave.fragments.RejectedFragment
import com.example.shualeduricda5.Leave.fragments.ReviewFragment
import com.google.android.material.tabs.TabLayoutMediator

class LeaveFragment : Fragment() {

    private lateinit var binding: FragmentLeaveBinding

    private val fList = listOf(
        ReviewFragment.newInstance(),
        ApprovedFragment.newInstance(),
        RejectedFragment.newInstance()
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLeaveBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViewPager()

        // ღილაკზე დაჭერისას გადავდივართ SubmitLeaveFragment-ზე
        binding.buttonSubmitLeave.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.placeholder, SubmitLeaveFragment.newInstance())
                .addToBackStack(null)
                .commit()
        }
    }

    private fun initViewPager() = with(binding) {
        val adapter = ViewpagerAdapter(requireActivity() as FragmentActivity, fList)
        vp.adapter = adapter

        val tabIcons = listOf(
            R.drawable.ic_review,
            R.drawable.ic_approvd,
            R.drawable.ic_rejected
        )

        TabLayoutMediator(tabLayout, vp) { tab, position ->
            tab.icon = ContextCompat.getDrawable(requireContext(), tabIcons[position])
            tab.text = when (position) {
                0 -> "Review"
                1 -> "Approved"
                2 -> "Rejected"
                else -> ""
            }
        }.attach()
    }

    companion object {
        fun newInstance() = LeaveFragment()
    }
}
